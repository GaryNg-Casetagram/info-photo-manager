
  # Claim Website Design

  This is a code bundle for Claim Website Design. The original project is available at https://www.figma.com/design/mHXieJLPpuu6ZQ3qYyjri9/Claim-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  